<?php
/**
 * ('-')
 * 
 * @package TreeBook
 * @author 龙介LongJie
 * @version 1.0.210203
 * @link http://longjie233.top
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
?>

			<div class="content index">
				<div class="headPage">
					<span><?php $this->options->title(); ?></span>
					<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
					<?php while($pages->next()): ?>
					<a<?php if($this->is('page', $pages->slug)): ?> class="current"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
					<?php endwhile; ?>
				</div>
				
				<?php while($this->next()): ?>
				<article>
					<div class="meta">
						<h1 class="article_title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
						<time><i class="fa fa-calendar"></i> <?php $this->date(); ?></time>
						<span class="category"><i class="fa fa-folder-open"></i> <?php $this->category(',',false); ?></span>
					</div>
					<div id="article_content" class="article_content">
						<?php $this->content('阅读剩余部分'); ?>
					</div>
				</article>
				<?php endwhile; ?>
			</div>

<?php $this->need('footer.php'); ?>
