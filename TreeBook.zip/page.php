<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

			<div class="content page">
				<article>
					<div class="meta">
						<h1 class="article_title"><?php $this->title() ?></h1>
						<time><i class="fa fa-calendar"></i> <?php $this->date(); ?></time>
					</div>
					<div id="article_content" class="article_content">
						<?php $this->content(); ?>
					</div>
				</article>
				<?php $this->need('comment.php'); ?>
			</div>

<?php $this->need('footer.php'); ?>