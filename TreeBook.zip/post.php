<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

			<div class="content">
				<article>
					<div class="meta">
						<h1 class="article_title"><?php $this->title() ?></h1>
						<time><i class="fa fa-calendar"></i> <?php $this->date(); ?></time>
						<span class="category"><i class="fa fa-folder-open"></i> <?php $this->category(',',false); ?></span>
					</div>
					<div id="article_content" class="article_content">
						<?php $this->content(); ?>
					</div>
				</article>
			</div>
			<div class="list">
				<ul></ul>
			</div>

<?php $this->need('footer.php'); ?>