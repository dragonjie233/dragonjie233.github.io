<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

		</div>
		<script src="<?php $this->options->themeUrl('hljs/highlight.js'); ?>" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript">hljs.initHighlightingOnLoad();</script>
		<script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(e) {
				$("#article_content").children().each(function(index, element) {
					var tagName=$(this).get(0).tagName;
					if(tagName.substr(0,1).toUpperCase()=="H"){  
						var contentH=$(this).html();//获取内容
						var markid="mark-"+tagName+"-"+index.toString();
						$(this).attr("id",markid);//为当前h标签设置id
						$(".list ul").append("<li><a href='#"+markid+"'>"+contentH+"</a></li>");//在目标DIV中添加内容   
					}  
				});
			});
			
			
			$(document).ready(function() {
				$('.panel span').click(function() {
					let button_id = $(this).attr('id');
					if($('.' + button_id).hasClass('on')) {
						$('.' + button_id).removeClass('on');
					} else {
						$('.' + button_id).addClass('on');
					}
					$('.content').click(function() {
						$('.' + button_id).removeClass('on');
					})
				});
				
				
				
				$('#directory li span').click(function() {
					if($(this).hasClass('directoryON')) {
						$(this).removeClass('directoryON');
					} else {
						$(this).addClass('directoryON');
					}
				});
			});
		</script>
		<?php $this->footer(); ?>
	</body>
</html>