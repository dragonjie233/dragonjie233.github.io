<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php $this->archiveTitle(array(
			'category'  =>  _t('分类 %s 下的文章'),
			'search'    =>  _t('包含关键字 %s 的文章'),
			'tag'       =>  _t('标签 %s 下的文章'),
			'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
		<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('style.css'); ?>"/>
		<link rel="stylesheet" type="text/css" href="<?php $this->options->themeUrl('hljs/atom-one-dark.css'); ?>"/>
		<link rel="stylesheet" type="text/css" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
	</head>
	<body>
		<div class="main">
			<div class="panel">
				<span id="directory"><i class="fa fa-list"></i></span>
				<span id="list"><i class="fa fa-columns"></i></span>
			</div>
			<div id="directory" class="directory">
				<ul>
					<li class="home"><a href="<?php $this->options->siteUrl(); ?>"><i class="fa fa-university"></i> 首页</a></li>
					<?php $this->widget('Widget_Metas_Category_List')->to($categories); ?>
					<?php while ($categories->next()): ?>
					
					<?php $this->widget('Widget_Archive@category-' . $categories->mid, 'pageSize=7&type=category', 'mid=' . $categories->mid)->to($posts); ?>
						<li>
							<span id="button-fl"><i class="fa fa-folder-open"></i> <?php $categories->name(); ?></span>
							<ul>
							<?php while ($posts->next()): ?> 
								<li><a href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a></li>
							<?php endwhile; ?>
							</ul>
						</li>
					<?php endwhile; ?>
				</ul>
			</div>